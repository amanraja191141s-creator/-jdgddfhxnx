# v98.63.9.24 — Scientific keypad reference alignment

- Rebuilt the 4×4 scientific function matrix to follow the supplied screen recording’s primary/inverse key arrangement.
- INV now switches the full function matrix and applies the selected inverse-trigonometric, inverse-hyperbolic, root and power token as a one-shot modifier.
- Preserved the scientific parser, expression editor, angle mode, memory, history, and additional-function panel.
- Applied a high-contrast pink scientific-key surface with consistent 48px minimum touch targets and visible focus/pressed states.
- Added regression coverage for matrix contents, inverse token routing, and reference styling.
