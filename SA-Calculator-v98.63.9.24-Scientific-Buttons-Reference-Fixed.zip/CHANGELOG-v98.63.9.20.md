# Changelog — v98.63.9.20

- Replaced the incorrect 46/54 keypad split with the video-matched right-to-left overlay drawer.
- The main keypad remains at 100% width and keeps its original button geometry.
- The drawer is positioned and sized from the live `.main-keypad` bounding box, so it overlays only the keypad band and never covers the main display.
- Drawer width is 90% (92% on narrow phones), leaving a slim portion of the normal keypad visible on the left as in the supplied recording.
- Added continuous pointer-driven drag tracking; the panel follows the finger and settles by drag distance or swipe velocity. Reverse swipe closes it.
- Rebuilt the 4×4 scientific function matrix to match the supplied video: INV, trig, ln/log, abs/factorial, constants, eˣ, square root, powers and More.
- DEG/RAD and close controls remain accessible in the compact drawer header. Extended functions remain under More.
- Scientific keys continue inserting into the main calculator expression engine and shared angle mode.
- Added click suppression after drag, pointer-cancel recovery, ResizeObserver geometry updates, Escape and accessibility inert/aria-hidden states.
- Updated app version, Android versionCode, service-worker cache identity and release workflow.

- Documentation consistency: clarified that the 46/54 split is the rejected prior implementation; the shipped v98.63.9.20 design is a 90%/92% overlay over a full-width keypad.
- Android workflow source discovery now gives every candidate archive a unique extraction directory, preventing same-version archives from overwriting one another during candidate selection.
