# QA — v98.63.9.13

Scope: uploaded 2026-11-20 keypad screenshot and latest v98.63.9.12 project.

Changes: prevent select option inventory text from being used as keypad labels; use explicit converter field labels; hide legacy app header only on calculator active screen.

Automated checks: run `npm test` and `npm run build:web` before Android workflow build.

Device-only checks still required: install generated APK on Android, verify calculator proportions on the target device, and exercise live currency provider/network behavior.
