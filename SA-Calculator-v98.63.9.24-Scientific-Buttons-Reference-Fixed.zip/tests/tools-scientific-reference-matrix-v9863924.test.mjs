import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/app.css','utf8');
const js=fs.readFileSync('assets/js/app.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const workflow=fs.readFileSync('.github/workflows/main.yml','utf8');
const sw=fs.readFileSync('service-worker.js','utf8');

test('v98.63.9.24 tool cards enforce horizontal readable labels in a responsive 3-column grid',()=>{
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card \{[\s\S]*?flex-direction:column!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?writing-mode:horizontal-tb!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card > \.premium-tool-name \{[\s\S]*?overflow-wrap:normal!important/);
  assert.match(css,/#screen-tools\.premium-tools-screen\.active[\s\S]*?overflow-y:auto!important/);
  const groups=html.match(/class="tools-reference-section"[\s\S]*?<\/div><\/div>/g)||[];
  const ids=[...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
  assert.equal(ids.length,16); assert.equal(new Set(ids).size,16);
  for (const id of ids) assert.ok(html.includes(`id="screen-${id}"`), `missing destination screen-${id}`);
  assert.match(js,/toolsGrid\?\.addEventListener\('click'/);
  assert.equal((html.match(/class="tools-reference-section"/g)||[]).length,4);
});

test('scientific overlay is wide enough for legible 4x4 controls and larger touch targets',()=>{
  assert.match(css,/#screen-calc #screen-scientific\.scientific-drawer \{[\s\S]*?width:min\(94vw,680px\)!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button \{[\s\S]*?min-height:48px!important/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid \{[\s\S]*?repeat\(4,minmax\(0,1fr\)\)!important/);
  const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
  assert.equal((grid.match(/<button\b/g)||[]).length,16);
  assert.match(js,/insertScientificIntoMain\(token\)/);
});

test('cache, PWA, app and Android workflow use one fresh v98.63.9.24 release identity',()=>{
  assert.equal(pkg.version,'1.98.71-v98.63.9.24');
  assert.match(html,/1\.98\.71-v98\.63\.9\.24/);
  assert.match(js,/APP_VERSION = '1\.98\.71-v98\.63\.9\.24'/);
  assert.match(sw,/v9863924-reference-scientific-matrix/);
  assert.match(workflow,/SA_EXPECTED_VERSION: '1\.98\.71-v98\.63\.9\.24'/);
  assert.match(workflow,/versionCode='1098072'/);
  assert.match(workflow,/v9863924-reference-scientific-matrix/);
});


test('scientific angle mode initializes from saved preference and exposes accessible state',()=>{
  assert.match(js,/initialAngleButton\.textContent = sci\.angle\.toUpperCase\(\)/);
  assert.match(js,/initialAngleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/angleButton\.setAttribute\('aria-pressed', String\(sci\.angle === 'rad'\)\)/);
  assert.match(js,/Angle mode \$\{sci\.angle\.toUpperCase\(\)\}; toggle degrees or radians/);
});

test('scientific controls retain 48px touch targets on short screens and expose keyboard focus',()=>{
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-function-grid > button \{ min-height:48px!important/);
  assert.match(css,/@media\(max-height:620px\) \{[\s\S]*?scientific-more-functions > button \{ min-height:48px!important/);
  assert.match(css,/#screen-tools \.tools-reference-grid > \.premium-tool-card:focus-visible/);
  assert.match(css,/#screen-calc #screen-scientific \.scientific-function-grid > button:focus-visible/);
});


test('scientific matrix matches the reference 4x4 primary and inverse function layout',()=>{
  const grid=html.match(/<div class="scientific-function-grid"[\s\S]*?<\/div>/)?.[0]||'';
  assert.equal((grid.match(/<button\b/g)||[]).length,16);
  for (const label of ['sin','cos','tan','ln','log','|x|','x!','π','e','eˣ','√','10ˣ','x²','xʸ']) assert.ok(grid.includes(`>${label}</button>`),`missing primary ${label}`);
  for (const token of ['asin(','acos(','atan(','sinh(','cosh(','tanh(','asinh(','acosh(','atanh(','cbrt(','2^(','^3','^(-']) assert.ok(grid.includes(`data-sci-alt-insert="${token}"`),`missing inverse ${token}`);
  assert.match(js,/const token = shiftActive && key\.dataset\.sciAltInsert \? key\.dataset\.sciAltInsert/);
  assert.match(js,/scientific-function-grid \[data-sci-alt-insert\]/);
});

test('reference scientific matrix has pink 4x4 surface, readable controls and active INV feedback',()=>{
  assert.match(css,/scientific-function-grid \{[\s\S]*?background:#f36591!important/);
  assert.match(css,/scientific-function-grid > button \{[\s\S]*?min-height:48px!important/);
  assert.match(css,/sci-shift-toggle\[aria-pressed="true"\]/);
  assert.match(css,/scientific-function-grid > #sci-more-toggle[\s\S]*?border-radius:50%!important/);
});
