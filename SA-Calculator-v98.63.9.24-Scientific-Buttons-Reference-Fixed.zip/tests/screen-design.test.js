const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8') + fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const sw = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');

test('screen design layer includes consistent touch targets, responsive layouts and safe areas', () => {
  assert.ok(css.includes('v1.97.1-v97.1 — retained screen-design layer; runtime changes are in app.js/server.js'));
  assert.match(css, /\.main-keypad \.key-btn \{ min-height:48px/);
  assert.match(css, /\.app-header \.icon-btn \{ width:48px; min-width:48px; height:48px; min-height:48px;/);
  assert.match(css, /\.settings-row \{ min-height:60px/);
  assert.match(css, /\.sumaire-picker-option\s*\{[\s\S]*?display:\s*grid\s*!important/);
  assert.match(css, /env\(safe-area-inset-bottom\)/);
  assert.match(css, /@media \(max-width:380px\)/);
  assert.match(css, /@media \(max-height:620px\)/);
  assert.match(css, /@media \(min-width:600px\)/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(css, /forced-colors:active/);
});

test('screen design update preserves all 18 registered app destinations and release cache version', () => {
  const screens = [...html.matchAll(/id="screen-[a-z0-9-]+"/g)].map(m => m[0]);
  assert.equal(new Set(screens).size, 22); // viewport plus 20 screens including the dedicated Tools destination
  assert.match(html, /1\.98\.65-v98\.63\.9\.17/);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});


test('v98.17 final design layer normalizes every registered screen and brand lockup', () => {
  assert.match(html, /class="brand-mark"/);
  assert.match(html, /sa-calculator-192\.png/);
  assert.match(html, /sa-calculator-512\.png/);
  assert.match(css, /SA Calculator v98\.15 — complete premium tool-screen redesign/);
  assert.match(css, /--sa-control-height: 50px/);
  assert.match(css, /@media \(min-width:600px\)/);
  assert.match(css, /@media \(max-height:700px\)/);
  const screens = [...html.matchAll(/id="screen-([a-z0-9-]+)"/g)].map(m => m[1]).filter(id => id !== 'viewport');
  assert.equal(screens.length, 21);
  for (const screen of screens) assert.ok(css.includes(`#screen-viewport .screen .calc-card`), `shared card rules missing for ${screen}`);
});

test('PWA manifest declares valid any and maskable icons at standard dimensions', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '192x192' && icon.purpose === 'any'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '512x512' && icon.purpose === 'any'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '512x512' && icon.purpose === 'maskable'));
});

test('v98.19 locks premium reference design coverage for every app destination and shared overlay', () => {
  const screens = ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings','favorites'];
  for (const screen of screens) assert.ok(css.includes(`#screen-${screen}`), `screen-specific design missing: ${screen}`);
  assert.match(css, /v98\.15 — complete premium tool-screen redesign/);
  assert.match(css, /#sidebar-drawer/);
  assert.match(css, /#history-modal/);
  assert.match(read('assets/css/app.css'), /\.sumaire-picker-panel/);
  assert.match(css, /#screen-scientific/);
  assert.match(css, /prefers-contrast: more/);
  assert.match(css, /forced-colors: active/);
  assert.match(html, /1\.98\.65-v98\.63\.9\.17/);
  assert.match(sw, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});

test('v98.17 replaces legacy light tool surfaces with the unified navy and premium card system', () => {
  assert.match(css, /--sa-navy-950: #030b1d/);
  assert.match(css, /background: linear-gradient\(180deg, #071a3b 0%, #06152f 56%, #040f25 100%\)/);
  assert.match(css, /#screen-calc \.calc-display/);
  assert.match(css, /#screen-currencies \.currency-parity-card/);
  assert.match(css, /#screen-settings \.settings-card/);
  assert.match(css, /prefers-reduced-motion: reduce/);
});


test('v98.17 matches supplied neon-blue reference design across all 18 screens', () => {
  assert.match(css, /SA CALCULATOR v98\.17 — FULL REFERENCE REBUILD/);
  assert.match(css, /--ref-cyan: #00dfff/);
  assert.match(css, /linear-gradient\(145deg,#a4ffbd 0%,#42ed82 52%,#0fbd59 100%\)/);
  assert.match(css, /linear-gradient\(110deg,#064de0 0%,#087fff 52%,#00bce9 100%\)/);
  assert.doesNotMatch(html, /SMART\s*<span>•<\/span>\s*POWERFUL|PREMIUM/);
  assert.match(read('assets/js/app.js'), /className = 'reference-screen-toolbar'/);
  assert.match(css, /#screen-viewport > \.screen:not\(#screen-calc\)::before,[\s\S]*?content:none !important/);
});


test('v98.19 enforces the single Premium Midnight Blue reference skin across legacy preferences', () => {
  const app = read('assets/js/app.js');
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  const bootstrap = read('assets/js/theme-bootstrap.js');
  assert.match(app, /const APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(app, /if \(!\['dark', 'light', 'system'\]\.includes\(val\)\) val = 'dark';/);
  assert.match(app, /color = \/\^#\[0-9a-f\]\{6\}\$\/i\.test\(String\(color\)\)/);
  assert.match(bootstrap, /#8b78ff/);
  assert.match(bootstrap, /data-theme', 'dark/);
  assert.match(html, /<option value="dark" selected>Dark<\/option>/);
  assert.equal((html.match(/class="theme-option"/g) || []).length, 1);
  assert.match(html, /data-theme-name="Violet"/);
  assert.match(css, /v98\.18 HARD REFERENCE SKIN/);
  assert.match(css, /background:linear-gradient\(180deg,#041b40 0%,#020b1d 100%\) !important/);
  assert.match(css, /#00dfff/);
});

test('v98.19 adds reference-style bottom navigation and favorites destination', () => {
  assert.match(html, /id="bottom-navigation"/);
  for (const tab of ['calc','history','favorites','tools']) assert.match(html, new RegExp(`data-bottom-nav="${tab}"`));
  assert.match(html, /id="screen-settings"/);
  assert.match(html, /id="screen-favorites"/);
  assert.match(html, /id="favorites-screen-list"/);
  assert.match(css, /\.bottom-navigation\s*\{/);
  assert.match(css, /\.favorite-tool-card\s*\{/);
  assert.match(read('assets/js/app.js'), /function initBottomNavigation\(\)/);
  assert.match(read('assets/js/app.js'), /function renderFavoritesScreen\(\)/);
});

test('v98.19 native dark theme uses blue actions, dark input fields and green result surfaces', () => {
  assert.match(css, /v98\.19 — NATIVE PREMIUM DARK REFERENCE SYSTEM/);
  assert.match(css, /background:#08162b/);
  assert.match(css, /background:var\(--theme-accent\)/);
  assert.match(css, /background:#07352f/);
  assert.match(css, /background:#08162b !important/);
  assert.match(css, /env\(safe-area-inset-bottom\)/);
});
