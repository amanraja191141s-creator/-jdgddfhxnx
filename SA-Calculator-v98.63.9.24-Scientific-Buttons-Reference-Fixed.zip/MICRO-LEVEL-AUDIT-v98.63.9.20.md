# Micro-level audit — v98.63.9.20

## Root cause from the supplied 5.36-second recording
The prior v98.63.9.19 implementation incorrectly shrank the standard keypad to 46% and placed a 54% panel beside it. The recording instead shows the scientific surface sliding from the right over the keypad; the standard keypad remains full size underneath, and the calculator display remains untouched.

## Corrected geometry and interaction
- Drawer top and height are measured from the live main keypad rectangle relative to the calculator screen.
- Drawer overlays 90% of the keypad width (92% at <=380px), leaving a narrow strip visible on the left.
- Main keypad width remains 100%; no split class is added.
- Right-edge gesture is accepted only in the keypad vertical band.
- Pointer movement continuously updates drawer offset; open/close settlement uses distance and velocity.
- Reverse swipe from the open panel closes it.
- Taps are not treated as swipes; post-drag click suppression prevents accidental scientific-key activation.
- ResizeObserver keeps overlay alignment correct when keypad geometry changes.
- Pointer cancellation restores the previous open state.
- Escape and explicit close remain available; hidden drawer is inert and aria-hidden.

## Function matrix
The visible matrix is 4 columns × 4 rows: INV, sin, cos, tan; ln, log, |x|, x!; π, e, eˣ, √; 10ˣ, x², xʸ, More. Additional inverse/log₂/cube-root/reciprocal/ANS controls remain in More. Scientific buttons insert into the main expression and use the shared DEG/RAD evaluator.

## Verification scope
Source-level syntax, regression tests, web bundle generation, workflow YAML parsing and ZIP integrity are checked. Actual Android WebView touch latency, OEM edge-gesture conflicts and physical-device visual comparison require installing the generated APK; they are not claimed as completed here.

## Follow-up package/workflow micro-audit

- Fixed workflow archive-candidate isolation: two or more ZIPs with the same package version no longer share and overwrite one temporary extraction directory.
- Fixed stale README wording that described the rejected 46/54 split as current behavior; release documentation now consistently describes the full-width keypad with the right-edge overlay.
- Release-gate tests and web-bundle generation were rerun after the changes. See `QA-RESULTS-v98.63.9.20.md` for exact scope and remaining device/legacy-suite limitations.
