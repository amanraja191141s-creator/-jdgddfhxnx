# Micro-level audit — v98.63.9.24

## Reference observations
The supplied 17.9-second recording shows a four-column/four-row scientific function surface. INV changes the visible matrix to secondary functions; the secondary state is used for one function press and then resets. The keypad panel is pink with dark labels, and the plus control is a circular action at the lower-right of the matrix.

## Implemented
- Reorganized the scientific matrix into a stable 4×4 primary/secondary layout.
- Corrected token selection so an active INV state uses the alternate token directly, then resets labels and pressed state.
- Kept the existing parser/evaluator, cursor editing, angle mode, memory/history and More panel rather than replacing the calculation engine.
- Added reference styling, 48px minimum key height, focus and pressed feedback.

## Limits
The recording does not expose the original app source or confirm the semantics of every proprietary key (notably the imaginary-unit key). The implementation therefore uses supported real-valued parser functions and does not claim complex-number support. Native Android installation, physical-device touch latency, OEM gesture behavior and visual parity on the user’s device still require device-side verification.
