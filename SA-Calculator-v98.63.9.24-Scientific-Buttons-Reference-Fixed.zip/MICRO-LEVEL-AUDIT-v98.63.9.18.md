# Micro-level audit — v98.63.9.18

## Source basis
Reviewed the supplied 5.36-second, 720×1560 Android screen recording and the v98.63.9.17 project archive. The recording shows the normal keypad remaining on the left while a scientific key panel is pulled in from the right edge; the previous source instead exposed Scientific Calculator as a separate full-screen destination in Tools.

## Root causes
1. Scientific controls lived in a standalone `.screen` and were navigated through the Tools catalog.
2. There was no right-edge gesture recognizer, drawer state, reverse-swipe close, or accessible close action.
3. Scientific UI inherited several older isolated-screen style layers, including unrelated gray/green styling that did not match the main calculator theme.
4. Existing startup restoration could attempt to reopen a stale `scientific` screen name saved by older builds.

## Corrections
- Reparented the existing scientific workspace into `#screen-calc` as an overlay drawer; all scientific control IDs and handlers remain intact.
- Added edge-origin pointer gesture recognition with horizontal/vertical thresholds to avoid triggering on ordinary taps or vertical scrolling.
- Added reverse swipe, close button, Escape support, `aria-hidden`, and `inert` handling.
- Removed the standalone Scientific Calculator tool card.
- Normalized a legacy saved `scientific` startup route back to the Calculator screen.
- Applied dark/light theme tokens and a responsive 88vw drawer width, bounded to keep a narrow strip of the normal calculator visible as in the reference recording.
- Updated the service-worker cache namespace and Android package/workflow version to v98.63.9.18.

## Preserved behaviour
Scientific expression editing, live evaluation, equals, DEG/RAD, SHIFT alternate functions, memory (MC/MR/M+/M−/MS), ANS, history, delete, clear and cursor movement remain wired to the existing scientific evaluator.

## Validation limits
Static regression checks, JavaScript syntax, Android web-bundle generation, YAML parsing and ZIP integrity are run for this release. A real Android APK install and touch/gesture verification on the user's phone remain required; automated source tests cannot certify physical-device smoothness or zero bugs.
