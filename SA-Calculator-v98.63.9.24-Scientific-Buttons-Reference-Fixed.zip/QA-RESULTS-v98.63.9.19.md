# QA results — v98.63.9.19

## Automated release suite
- 36 tests passed
- 0 tests failed
- Includes calculator arithmetic/parser regression, scientific notation boundaries, scientific function/angle behavior, Tools catalog checks, and eight focused scientific side-panel integration tests.

## Build and static checks
- `node --check assets/js/app.js`: PASS
- `node --check www/assets/js/app.js`: PASS
- `npm run build:web`: PASS; 13 required assets verified and copied
- Root/index and `www/index.html` byte comparison: PASS
- Root stylesheet and `www/assets/css/app.css` byte comparison: PASS
- Android workflow YAML syntax: PASS
- ZIP integrity: PASS

## Important validation boundary
No Android APK was installed on the user's physical device in this environment. Gesture start-zone behavior, OS edge-gesture conflicts, touch latency, and screenshot pixel matching still require a fresh APK on the target phone. Automated tests verify source wiring and layout rules, not device certification.
